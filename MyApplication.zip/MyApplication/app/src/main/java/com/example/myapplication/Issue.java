package com.example.myapplication;

// Create a model class to represent GitHub issues
public class Issue {
    private String title;
    private String created_at;
    private String closed_at;
    private User user;

    public String getTitle() {
        return title;
    }

    public String getCreated_at() {
        return created_at;
    }

    public String getClosed_at() {
        return closed_at;
    }
    public User getUser() {
        return user;
    }



    // Getters and setters

    public static class User {
        private String login;
        private String avatar_url;

        public String getLogin() {
            return login;
        }

        public String getAvatar_url() {
            return avatar_url;
        }
        // Getters and setters
    }
}
