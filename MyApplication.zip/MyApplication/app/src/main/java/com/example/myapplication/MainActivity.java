package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private GitHubApi gitHubApi;
    private ListView issuesListView;
    private EditText searchEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.github.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        gitHubApi = retrofit.create(GitHubApi.class);

        issuesListView = findViewById(R.id.issuesListView);
        searchEditText = findViewById(R.id.searchEditText);

        // Fetch closed issues and display them
        fetchClosedIssues();

        // Set up search functionality
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Filter the issues based on the search query
                filterIssues(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
    }

    private void fetchClosedIssues() {
        Call<List<Issue>> call = gitHubApi.getClosedIssues("owner", "repo", "closed");

        call.enqueue(new Callback<List<Issue>>() {
            @Override
            public void onResponse(Call<List<Issue>> call, Response<List<Issue>> response) {
                if (response.isSuccessful()) {
                    List<Issue> issues = response.body();
                    displayIssues(issues);
                } else {
                    // Handle error
                    Toast.makeText(MainActivity.this, "Error loading issues", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Issue>> call, Throwable t) {
                // Handle failure
                Toast.makeText(MainActivity.this, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void displayIssues(List<Issue> issues) {
        // Create an adapter to display the issues in a ListView
        IssueAdapter adapter = new IssueAdapter(this, issues);
        issuesListView.setAdapter(adapter);
    }

    private void filterIssues(String query) {
        // Implement filtering logic based on the search query
        // Update the adapter with the filtered results
    }
}
