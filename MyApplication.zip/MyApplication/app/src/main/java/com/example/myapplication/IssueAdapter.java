package com.example.myapplication;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class IssueAdapter extends ArrayAdapter<Issue> {

    private Context context;
    private List<Issue> issues;

    public IssueAdapter(Context context, List<Issue> issues) {
        super(context, R.layout.issue_item, issues);
        this.context = context;
        this.issues = issues;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.issue_item, parent, false);
        }

        TextView titleTextView = convertView.findViewById(R.id.titleTextView);
        TextView createdDateTextView = convertView.findViewById(R.id.createdDateTextView);
        TextView closedDateTextView = convertView.findViewById(R.id.closedDateTextView);
        TextView userNameTextView = convertView.findViewById(R.id.userNameTextView);
        ImageView userImageView = convertView.findViewById(R.id.userImageView);

        Issue issue = issues.get(position);

        titleTextView.setText(issue.getTitle());
        createdDateTextView.setText("Created: " + issue.getCreated_at());
        closedDateTextView.setText("Closed: " + issue.getClosed_at());
        userNameTextView.setText("User: " + issue.getUser().getLogin());

        // Use Picasso to load the user's avatar
        Picasso.get().load(issue.getUser().getAvatar_url()).into(userImageView);

        return convertView;
    }
}
