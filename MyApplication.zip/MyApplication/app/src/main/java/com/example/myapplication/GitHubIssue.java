package com.example.myapplication;

// GitHubIssue.java
public class GitHubIssue {
    private String title;
    private String createdDate;
    private String closedDate;
    private String userName;
    private String userImageURL;

    // Constructors, getters, and setters
}

